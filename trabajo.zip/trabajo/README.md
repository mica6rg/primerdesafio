** APP 'DESAFIO INTEGRADOR'. ** 

La app 'DESAFIO INTEGRADOR' permite acceder a una base de datos y realizar distintas peticiones de información según los parámetros que desee ingresar el usuario. La misma consta de 3 módulos:

1. DB.js --> Es el encargado de contener la Base de Datos (colección de objetos). Cada objeto representa un libro. 

2. INDEX.js --> Encargado de recibir y procesar los parámetros desde la terminal al ejecutar el archivo principal. Utiliza las funciones definidas en BOOKS.js.

3. BOOKS.js --> Es el encargado de definir la lógica de las funciones que actúan sobre DB.js. Consta de las siguientes funciones:

- **getAll() --> Devuelve un array con todos los libros.**
- **getById(id) -->** **Devuelve el libro cuyo ID es el indicado por parámetro.**
- **getByName(name) --> Devuelve el libro cuyo nombre es el indicado por parámetro.**
- **getByTag(tag) --> Devuelve un array con los libros que contengan la etiqueta indicada por párametro.**
- **getByAuthor(author) --> Devuelve un array con los libros cuyo nombre de autor es el indicado por parámetro.**
- **getSoldByAuthor(author) --> Devuelve la cantidad total de libros vendidos que tenga el autor indicado por párametro.**

Para ejecutar esta app desde la consola, el usuario deberá ingresar los argumentos correspondientes en la misma, en la cual previamente se ejecuta el archivo index.js utilizando node.js. La estructura a seguir es la siguiente:

node index.js --propiedad valor

*Utilizar _ para los espacios.
