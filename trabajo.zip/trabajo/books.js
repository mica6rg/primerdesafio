const books = require("./db");

const getAll = () => {
    return books;
}

const getById = (id) => {
    const bookById = books.find(book => book.id === id);
    return bookById ? bookById : 'ERROR: No hay coincidencias con el ID indicado';
}

const getByName = (name) => {
    const bookByName = books.filter((book) => book.name.includes(name));
    if (bookByName.length > 0) {
        return bookByName;
    }
    else {
        return 'ERROR: No hay coincidencias con el nombre indicado';
    }
};

const getByTag = (tag) => {
    const booksByTag = books.filter((book) => book.tags.map(tag => tag.toLowerCase()).includes(tag.toLowerCase()));

    return booksByTag.length > 0 ? booksByTag : 'ERROR: No hay coincidencias con el tag indicado';
}

const getByAuthor = (author) => {
    const booksByAuthor = [];

    books.forEach((book) => {
        if (book.author.toLowerCase().includes(author.toLowerCase())) {
            booksByAuthor.push(book.name)
        }
    })
    return booksByAuthor.length > 0 ? booksByAuthor : 'ERROR: No hay coincidencias con el autor indicado';
};

const getSoldByAuthor = (author) => {
    const soldBooks = books.reduce((accumulator, book) => {
        return book.author.toLowerCase() === author.toLowerCase() ? accumulator + book.sold : accumulator;
    }, 0);

    return soldBooks > 0 ? soldBooks : 'ERROR: No hay coincidencias con el autor indicado';
};


module.exports = {getAll,
getById,
getByName,
getByTag,
getByAuthor,
getSoldByAuthor,
};


