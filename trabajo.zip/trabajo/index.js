const processesArguments = require("./functionProcessArgv");
const books = require('./books');

const main = () => {
  const processedArguments = processesArguments(process.argv);

  const bookName = processedArguments.name
  const bookId = processedArguments.id
  const bookAuthor = processedArguments.author
  const bookTag = processedArguments.tags
  const bookSold = processedArguments.sold

  if (bookName) {
    console.log(books.getByName(bookName));
  }
  if (bookId) {
    console.log(books.getById(bookId));
  }
  if (bookTag) {
    console.log(books.getByTag(bookTag));
  }
  if (bookAuthor) {
    console.log(books.getByAuthor(bookAuthor));
  }

  if (bookSold) {
    console.log(books.getSoldByAuthor(bookSold));
  }


  if (Object.keys(processedArguments).length === 0) {
    console.log(books.getAll());
  } else if (!bookName && !bookId && !bookTag && !bookAuthor && !bookSold) {
    console.log('ERROR: No hay coincidencias con la propiedad indicada');
  }
};

  main();


